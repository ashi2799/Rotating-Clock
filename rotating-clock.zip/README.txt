A Pen created at CodePen.io. You can find this one at http://codepen.io/V17h3m/pen/XdYEjR.

 Click the CLOCK to change the style.